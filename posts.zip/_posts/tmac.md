layout: post
title: Tracy McGrady
date: 2014-06-08 16:28:42
categories: [收藏]
tags: [NBA,Basketball]
---
##如果可以有如果...##
<!--more-->
&emsp;&emsp;这个神奇的男子，已经不需要我来介绍。在他被伤病摧毁了之后，留下了太多的遗憾。然而我要感谢他，感谢他的天份打开我在思维里对篮球的局限。祝福他在棒球场上仍然可以找到自己的一片天地。


###video1###
**`Tracy McGrady The Lost Legend`**
<video controls preload="none" width="640" height="320" poster="http://photo4blog.qiniudn.com/Tracy_McGrady_The_Lost_Legend.png">
 <source src="http://video4blog.qiniudn.com/Tracy_McGrady_The_Lost_Legend.mp4" type='video/mp4'>
</video>
<br/>
<br/>
###video2###
**`Throwback Tracy McGrady 13 Points In 33 Seconds vs Spurs 12 09 2004`**
<video controls preload="none" width="640" height="320" poster="http://photo4blog.qiniudn.com/Throwback_Tracy_McGrady_13_Points_In_33_Seconds_vs_Spurs_12_09_2004.png">
 <source src="http://video4blog.qiniudn.com/Throwback_Tracy_McGrady_13_Points_In_33_Seconds_vs_Spurs_12_09_2004.mp4" type='video/mp4'>
</video>
<br/>
<br/>
###video3###
**`13pts in 35s全过程`**
<video controls preload="none" width="640" height="320" poster="http://photo4blog.qiniudn.com/2004_NBA_Rockets_v_Spurs_Tracy_McGrady_scores_13pts_in_33secs_to_win_the_game.png">
 <source src="http://video4blog.qiniudn.com/2004_NBA_Rockets_v_Spurs_Tracy_McGrady_scores_13pts_in_33secs_to_win_the_game.mp4" type='video/mp4'>
</video>
<br/>
<br/>