layout: post
title: 吉他和弦指法
date: 2014-06-08 09:29:13
categories:
tags:
---


![吉他和弦指法](http://photo4blog.qiniudn.com/full-standard-chord-chart.jpg)