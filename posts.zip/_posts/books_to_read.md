title: 'Books To Read'
date: 2014-05-07 20:04:56
categories:
tags: [Books,积累]
---

<!--more-->
---
* 双城记
![](http://photo4blog.qiniudn.com/%E5%8F%8C%E5%9F%8E%E8%AE%B0.jpg)
* 禅与摩托车维修艺术
![](http://photo4blog.qiniudn.com/%E7%A6%85%E4%B8%8E%E6%91%A9%E6%89%98%E8%BD%A6%E7%BB%B4%E4%BF%AE%E8%89%BA%E6%9C%AF.jpg)
+ 人间喜剧
 * 欧也尼 葛朗台
 * 高老头

![](http://photo4blog.qiniudn.com/%E4%BA%BA%E9%97%B4%E5%96%9C%E5%89%A7.jpg)

- Tolstoy 托尔斯泰 1828-1910
 * 人类良心的代表
 《童年》《少年》《青年》《一个地主的早晨》《哥萨克》《克莱采奏鸣曲》《哈吉姆拉特》





---
