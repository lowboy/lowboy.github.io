layout: post
title: 期末考试求不跪
date: 2014-06-12 11:44:37
categories:
tags:
---
**祝福我和我的小伙伴们都能期末顺利吧！**
<!--more-->
<div align="center">
<img src="http://photo4blog.qiniudn.com/testgod.jpg" />
</div>
---