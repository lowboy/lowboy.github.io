layout: post
title: Mosquitos
date: 2014-08-03 09:40:05
categories: [随笔]
tags: [没事闲的]
---
#也许多年后会有一个诗人这样写道#
<!--more-->


			喜欢上
			一个
			不该喜欢上的
			人
			就像
			蚊帐里
			驻进了
			一只
			善于躲藏的
			蚊子
			让你
			内心惶恐
			躁动不安
			却偏又
			无计可施