layout: post
title: 迎战2014世界杯
date: 2014-06-14 21:25:06
categories:
tags:
---
Lowboy收集了了几款在线直播，不过切记**熬夜伤身**。
<!--more-->
>如果下面的两个视频同时播放造成**`卡顿`**，可以选择停止其中的一个，
通过点击**控制栏正中`方块状`**的“停止”按钮，即可实现。
<br/>

##CCTV-5##
<iframe src="http://live.64ma.com/tv/tv.asp?pid=cctv5" preload="none" height="420" width="800" frameborder="0" marginwidth="0" marginheight="0"scrolling="no"></iframe>
<br/>
<h1>CCTV-5+</h1>
<iframe src="http://live.64ma.com/tv/tv.asp?pid=cctvgaoqing" preload="none" height="420" width="800" frameborder="0" marginwidth="0" marginheight="0"scrolling="no"></iframe>