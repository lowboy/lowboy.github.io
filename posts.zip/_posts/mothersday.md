layout: post
title: 祝所有母亲身体健康，诸事合意!
date: 2014-05-09 12:27:52
categories: 
tags: 
feature: http://photo4blog.qiniudn.com/mother.gif?imageView/2/h/200/format/jpg
description: 
---
<!--more-->
<div align="center">
<img src="http://photo4blog.qiniudn.com/mother.gif" align="center"/>
</div>
<audio src="http://music4blog.qiniudn.com/%E5%90%AC%E5%A6%88%E5%A6%88%E7%9A%84%E8%AF%9D%20-%20%E5%91%A8%E6%9D%B0%E4%BC%A6.mp3" preload="auto" />
