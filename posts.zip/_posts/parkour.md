layout: post
title: 跑酷
date: 2014-06-07 12:00:43
categories:
tags: [parkour,跑酷]
---
<!--more-->
附上两段视频
##第一段##
这个视频的名字就叫做
**`UNDERESTIMATED`**
&emsp;&emsp;我忽然间发现已经不知道有多久让自己习惯于自我否定、自我限制了。令我感动的是里面居然有一个不到十岁的小男孩。
&emsp;&emsp;这个世界上最悲哀的事情莫过于：
>**我以为自己不行，但其实我可以。**

<video  controls preload="none" width="640" height="360" poster="http://photo4blog.qiniudn.com/UNDERESTIMATED.png">
 <source src="http://video4blog.qiniudn.com/UNDERESTIMATED.mp4" type='video/mp4'>
 </video>

##第二段##
**`The World‘s Best Parkour and Freerunning 2013`**
<video  controls preload="none" width="640" height="264" poster="http://photo4blog.qiniudn.com/The_World_s_Best_Parkour_and_Freerunning.png">
 <source src="http://video4blog.qiniudn.com/The_World_s_Best_Parkour_and_Freerunning.mp4" type='video/mp4'>
 </video>

&emsp;&emsp;我猜很难有人相信我会喜欢这种运动，就像很难有人猜到我喜欢Eminem一样，我想这是因为我心里有一半Wild的部分。
&emsp;&emsp;之前总是纠结，不知道自己会变成什么样子。我企图将两个自己融合，但可惜失败了，需要理性的时候不够理性，需要勇敢的时候又被自己限制。我害怕自己wild的部分，把他紧紧限制，却无意间把懦弱养大。也只有在看Parkour和听Eminem的时候，那部分的自己才能够觉醒吧。
&emsp;&emsp;不过今后，我决定放开限制，两个自我各自发展，互不影响，希望这能开启一个新的时代。
