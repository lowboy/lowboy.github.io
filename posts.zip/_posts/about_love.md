layout: post
title: 关于爱情
date: 2014-08-09 20:30:32
categories:
tags: [随笔]
---
#未完成
<!--more-->
&emsp;&emsp;今天试图写这篇早计划好要写的**《关于爱情》**，并一口气写出了我的某种程度的 Dark past, 经过之后的一番剖析，我只好无奈得出了一个结论：

			我是渣男
			如果恋爱
			唯一的结果就是坑了别人
			所以还是自己玩吧

Well , the fact is that I've been wasting so much time criticizing myself of being rotten and deserved to be alone .

But I forget that I still have the ablity to fight .

我应当努力去赢得我想要的每一场胜利，不论是学习、作业、项目、比赛，还是友情，甚至是现在还不敢想的爱情，都应该去拼一拼。

一个人的不幸的经历，的确是会给他的心理、行为趋向以及价值观带来负面的影响。

可不论发生过什么，经历过什么，没有理由用未来的幸福为过去的不幸陪葬。

所以我删掉了那一篇长文，一个字也不准备留下，如果有机会，我可能会把我的故事说给几个人听，也或许不会有人知道了。


我还有梦和爱的权利，不该毁了我的一切，更不该永远的离开。

我不想步朴树的后尘，虽然他是一个优秀的歌手。

这么多年我都没有自闭成功，一定是因为它困不住我，

而我，终究可以走的出来。

Go to win your life and win somebody's heart , before it is too late .

>I gotta go and see about a girl .

<br/>
---
日期|心态|行动
---|---|---
2014-08-10|Negative|差得远呢
2014-08-11|Positive|差得远呢
2014-08-12|Positive|差得远呢
2014-08-13|Positive|差得远呢