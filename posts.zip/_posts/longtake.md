layout: post
title: 电影史上优秀的镜头
date: 2014-06-09 01:03:41
categories: 
tags: [长镜头,Movies,Mise-en-scene,电影,Entertainment]
feature: http://photo4blog.qiniudn.com/atonement.jpg
toc: ture
---
<!--more-->
&emsp;&emsp;被标题骗了的人，如果你以为我很了解电影史，以为我要长篇大论，那你就错了，我只是列出我自己的观影史而已～
><font color="#ff0000" size="6px">*注意:  *</font><font color="#ff0000">请不要 **呵呵** 哦～ </font>


##长镜头篇##
###Atonement 赎罪###
&emsp;&emsp;把这部电影的长镜头放在最前，因为它的形式最经典，即镜头始终跟随人物运动，使得宏大的场景都得以一一呈现。
&emsp;&emsp;这组长镜头的复杂度很高，表现力惊人。
<video controls preload="none" width="640" height="320" poster="http://photo4blog.qiniudn.com/atonement.jpg">
 <source src="http://video4blog.qiniudn.com/longtake-atonement.mp4" type='video/mp4'>
</video>

<br/>
<br/>
<br/>


###Children Of Men 人类之子###
>看过这部电影，才能体会导演阿方索·卡隆（Alfonso Cuarón）的功力，虽然凭借`Gravity`得到的奥斯卡最佳导演奖水份略大，但如果考虑到`人类之子`和之前`哈利波特与阿兹卡班囚徒`的影响，我觉得还算是实至名归的。

####Clip 1####
&emsp;&emsp;这一段长镜头时长略短，只有4分钟左右，但相应地，节奏也略快。
&emsp;&emsp;有别于一般常见的让摄像机跟着人物和情节一路走下去长镜头，这一组没有在空间上发生长位移，而是将一切局限在非常狭小的空间。导演通过人物活动和对话牵引镜头转移，使得情节发展平滑自然、行云流水，实在是不可多得的佳作。虽然有人说这一段是`伪长镜头`，中间有偷换的场景，还有`电脑特技制作的乒乓球`，但是Who cares!!!
&emsp;&emsp;就当作是新技术给长镜头这一艺术表现形式以新的生命吧。
<video  controls preload="none" width="640" height="320" poster="http://photo4blog.qiniudn.com/Children-Of-Men-longtake1.png">
 <source src="http://video4blog.qiniudn.com/Children-Of-Men-longtake1.mp4" type='video/mp4'>
</video>

<br/>

####Clip 2####
&emsp;&emsp;这一组长镜头时长略长，也是`人类之子`中最知名的长镜头，在超过10分钟的时间里展现出人性的恶与善、战争的残酷和不同的人对人类未来的不同选择和坚持，几乎就是它成就了`人类之子`的知名度和在电影史上的地位，使更多的人能够留意到这一部不那么好看的oppressive&desperate的电影。
&emsp;&emsp;虽然我怀疑导演在4分17秒把镜头摇了上去之后，把镜头前的血迹擦掉了，不过这并没有对流畅度产生多大的影响。
<video  controls preload="none" width="600" height="400" poster="http://photo4blog.qiniudn.com/Children-Of-Men-longtake2.png">
 <source src="http://video4blog.qiniudn.com/Children-Of-Men-longtake2.mp4" type='video/mp4'>
</video>




##场面调度篇##
&emsp;&emsp;光影的变化和人物站位实在是太赞了，要是夸起来要好半天，但是看过一遍就都知道了。
<video  controls preload="none" width="600" height="400" poster="http://photo4blog.qiniudn.com/atonement-mise-en-scene.png">
 <source src="http://video4blog.qiniudn.com/atonement-mise-en-scene.mp4" type='video/mp4'>
</video>