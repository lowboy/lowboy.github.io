title: 破解 Sublime-build-3059
date: 2014-05-06 23:07:34
categories: 
tags: [sublime,破解]
---
<!--more-->
*来源于网络大神，只需要替换原来的主程序文件即可。*
<br/>
##破解补丁下载地址
[*Windows 32bit*][1]

[*Windows 64bit*][2]

[*Linux 32bit*][3]

[*Linux 64bit*][4]

[*Mac OS*][5]

---
##参考文章地址
[【分享】Sublime Text Build 3059 发布及破解文件(Windows/Linux/32/64/Mac全版本)][6]

[1]: http://pan.baidu.com/s/13YCEU
[2]: http://pan.baidu.com/s/1pJz4vRd
[3]: http://pan.baidu.com/s/1bn6Eyjd
[4]: http://pan.baidu.com/s/1hqBnTBI
[5]: http://pan.baidu.com/s/1bnu3ibl
[6]:http://bbs.pediy.com/showthread.php?p=1248869