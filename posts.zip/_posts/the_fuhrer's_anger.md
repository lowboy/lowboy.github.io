layout: post
title: 水工帝怒斥香港记者
date: 2014-08-09 12:26:09
categories: [收藏]
tags: [积累]
list_number: false
---
##水工帝的神段子，引领了一个时代的潮流
<!--more-->
&emsp;&emsp;现在网上流传最广的**图样图森破**，**naive(拿衣服)**，皆出于此。
<br/>
###名句集锦：
>`你们问我支持不支持，我当然支持了;`<br/>
`你们啊，总是想搞个大新闻;`<br/>
`too young too simple;`<br/>
`sometimes naive;`<br/>
`告诉你们啊，我是身经百战，见得多了;`<br/>
`美国的华莱士，比你们不知道高到哪里去了，我和他谈笑风声;`<br/>
`身为一个长者，我有必要告诉一些你们的人生经验;`<br/>
`中国有句俗话叫“闷生大发财”;`(后来有**“闷声发大财”**和**“闷声作大死”**等变种，源头都应当在这里)<br/>

###附上视频：
<video controls preload="none" width="600" height="400" poster="http://photo4blog.qiniudn.com/i_am_angry.png">
 <source src="http://video4blog.qiniudn.com/i_am_angry.mp4" type='video/mp4'>
</video>